# movie-crawl

## Movie crawling for use in AWS Lambda

- Using build script `./build.sh` -> `build.zip`
- After build upload build file to AWS Lambda